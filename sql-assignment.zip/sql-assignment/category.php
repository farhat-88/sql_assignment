<?php include('header.php'); ?>
<?php include('navbar.php'); ?>

        <?php
        
            if(isset($_POST['submit']))
            {
                $query  = "INSERT INTO category(category_name, brand_id) VALUES ('{$_POST['category_name']}',
                '{$_POST['brand_id']}') "; 
                $result =  mysqli_query ($link, $query);

                if(mysqli_errno($link))
                    {
                        echo mysqli_error($link);
                    }

                if($result)
                    {
                      
                        header('location:category.php');
                    }

            }
      
            $query      = "SELECT * FROM brand";
            $result     =  mysqli_query($link, $query);
            $companies   =  mysqli_fetch_all($result , 1);

        
            $query="SELECT category.id,category.category_name,brand.brand_name
            FROM category inner join brand on category.brand_id = brand.id";
            $result= mysqli_query($link,$query);
            $categories= mysqli_fetch_all($result, 1);
            $noOfRecords= mysqli_num_rows($result);
            $perPageRecords=3;
            $numOfPages= ceil($noOfRecords / $perPageRecords) ;
            
            $offSet= isset($_GET['offSet']) ? $_GET['offSet'] - 1 : 0;
            $ofSetRecord = $offSet * $perPageRecords;


            $query="SELECT category.id,category.category_name,brand.brand_name
            FROM category inner join brand on category.brand_id = brand.id limit $ofSetRecord, $perPageRecords";
            $result= mysqli_query($link,$query);
            $categories= mysqli_fetch_all($result, 1);
        
           
        ?>

        <div class="container py-3">
            <div class="row">
              <div class="col-md-12">
                <div class="row justify-content-center">
                  <div class="col-md-12">
                    <form method="POST"> 
                        <div class="form-group col-6">
                            <label >category</label>
                            <input type="text" class="form-control" name="category_name"  placeholder="category_Name">
                        </div>


                        <div class="form-group col-6">
                            <label >brand-id</label>
                            <select name = "brand_id" class="form-control">
                                <option value = "">Select Brand</option>

                                <?php foreach($companies as $brand){
                                ?>
                                <option value = "<?php echo $brand["id"]?> ">
                                    <?php echo $brand["brand_name"]?>
                                </option>
                                <?php
                                }?>
                            </select>
                                
                        </div>
                        <button type="submit" name= "submit" class="btn btn-primary ml-3">Submit</button>
                    </form>
                  
                    <?php
                                
                                if(isset($_POST['filter_to']) && !empty(trim($_POST['filter_to'])))
                                {
                                $query = "SELECT category.id,category.category_name,brand.brand_name 
                                            FROM category INNER JOIN brand ON category.brand_id = brand.id 
                                            WHERE category.category_name Like \"%{$_POST['filter_to']}%\" or 
                                            brand.brand_name Like \"%{$_POST['filter_to']}%\" 
                                            ";
                                            $result= mysqli_query($link,$query);
                                            $categories= mysqli_fetch_all($result, 1);
                                
                                
                                }else
                                
                                    {
                                        $query = "SELECT category.id,category.category_name,brand.brand_name 
                                        FROM category INNER JOIN brand ON category.brand_id = brand.id ";
                                        $result= mysqli_query($link,$query);
                                    }
                               ?>
                    <?php
                                    if(isset($_POST['order_by'])){
                                        $query      = "SELECT category.id,category.category_name,brand.brand_name 
                                        FROM category INNER JOIN brand ON category.brand_id = brand.id ORDER BY {$_POST['order_by']} {$_POST['order_with']}";
                                        $result = mysqli_query($link,$query);
                                        $categories =  mysqli_fetch_all($result , 1);
                                       
                                    }else
                                    {
                                        $query      = "SELECT * FROM category";
                                        $result= mysqli_query($link,$query);
                                    } 
                    ?>
                    <div class="col-12 mt-3">
                        <div class="col-12">
                            <div class="row">
                                <div class="col-6">
                                    <form method="POST" class="form_inline">
                                        <div class="form-group mt-2 d-inline-block">
                                            <select name="order_by">
                                                <option value="category_name">Order by category</option>
                                                <option value="category_name">Order by brand name</option>
                                            </select>
                                        </div>
                                        <div class="form-group  mt-2 d-inline-block">
                                            <select name="order_with">
                                                <option value="asc">Assending</option>
                                                <option value="desc">Decending</option>
                                            </select>
                                        </div>
                                        <div class="form-group  mt-2 d-inline-block">
                                            <button type="submit" name= "sorting" class="btn btn-primary p-1">Sort</button>
                                        </div>
                                    </form>
                                </div>
                              
                               
                                <div class="col-6">
                                    <form method="POST" class="form-inline float-right">
                                        <div class="form-group  mt-2">
                                            <input type="text" class="form-control" name ="filter_to" placeholder = "Search....">
                                        </div>
                                        <div class="form-group mt-2">
                                            <input type="submit" class="btn btn-primary ml-3" value="filter">
                                        </div>
                                        
                                    </form>
                                </div>
                            </div>
                        </div>
                       
                        <table class="table table-striped pt-2">
                            <thead>
                                <tr>
                                <th scope="col">#</th>
                                <th scope="col">Category</th>
                                <th scope="col">Brand_Name</th>
                                <th scope="col"> Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                if(count($categories) > 0){
                                ?>
                                <?php foreach($categories as $category){
                                ?>
                                <tr>
                                    <td><?php echo $category['id'];?> </td>
                                    <td><?php echo $category['category_name'];?></td>
                                   <td><?php echo $category['brand_name'];?></td>
                                   <td>
                                        <a href= "category_edit.php?category_id=<?php echo $category['id']; ?>" class="btn btn-primary"> <i class="fas fa-edit"></i></a>
                                        <a href= "category_delete.php?category_id=<?php echo $category['id']; ?>" class="btn btn-danger"> <i class="fas fa-trash-alt"></i></a>
                                    </td>
                                </tr>
                                <?php    
                                }
                                ?>
                                <?php
                                } else{?>
                                <tr>
                                    <td>RECORD NOT FOUND</td>
                                </tr>
                            <?php
                                }
                                ?>
                            </tbody>
                        </table>
                        <?php
                                for($i=1; $i<= $numOfPages; $i++)  
                                {
                                    echo "<a href='category.php?offSet=$i' class='btn btn-outline-primary'>$i</a>";
                                }     
                        ?>
                    </div>
                  </div>
                </div>
             
                </div>
              </div><!--/col-->
            </div><!--/row-->
          </div><!--/container-->


        
        

      
        <?php include('footer.php'); ?>