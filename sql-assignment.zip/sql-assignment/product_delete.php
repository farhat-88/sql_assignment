<?php require_once('connection.php'); ?>
<?php
    
    if(isset($_GET['product_id']))
    {
        if(!empty($_GET['product_id']))
        {
            $query = "DELETE FROM product where id = '{$_GET['product_id']}'";
            $result     =  mysqli_query($link, $query);

            if($result)
            {
                header('location:products.php');
            }
        }  
    }

?>