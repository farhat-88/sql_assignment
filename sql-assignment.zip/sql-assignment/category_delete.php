<?php require_once('connection.php'); ?>
<?php
    
    if(isset($_GET['category_id']))
    {
        if(!empty($_GET['category_id']))
        {
            
            $query = "DELETE FROM category where id = '{$_GET['category_id']}'";
            $result     =  mysqli_query($link, $query);

            if($result)
            {
                
                header('location:category.php');
               
            }
        }  
    }

        
       ?>