
        
        
        <?php
            $query="SELECT * FROM category";
            $resultset= mysqli_query($link,$query);
             
            $noOfRecords= mysqli_num_rows($resultset);
            $perPageRecords=3;
            $numOfPages= ceil($noOfRecords / $perPageRecords) ;
            $offSet= isset($_GET['offSet']) ? $_GET['offSet'] - 1 : 0;
            $ofSetRecord = $offSet * $perPageRecords;


            $query="SELECT * FROM category limit $ofSetRecord, $perPageRecords";
            $resultset= mysqli_query($link,$query);
            $category= mysqli_fetch_all($resultset, 1);
            
        
        ?>

        <div class="pt-5 col-8">
      
      
        
        </div>
     

        <?php include('footer.php'); ?>