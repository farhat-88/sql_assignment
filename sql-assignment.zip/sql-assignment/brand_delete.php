<?php require_once('connection.php'); ?>
<?php
    
    if(isset($_GET['brand_id']))
    {
        if(!empty($_GET['brand_id']))
        {
            
            $query = "DELETE FROM brand where id = '{$_GET['brand_id']}'";
            $result     =  mysqli_query($link, $query);

            if($result)
            {
                
                header('location:brand.php');
               
            }
        }  
    }

?>