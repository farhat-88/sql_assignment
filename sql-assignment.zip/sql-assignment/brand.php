<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
        <?php
         
           if(isset($_POST['brand_name']))
           {
                if(!empty($_POST['brand_name']))
                {
                    $query  = "INSERT INTO brand  (brand_name) VALUES ('{$_POST['brand_name']}')";
                    $result =  mysqli_query ($link, $query);

                    if(mysqli_errno($link))
                    {
                        echo mysqli_error($link);
                    }

                    if($result)
                    {
                        header('location:brand.php');
                    }
                }
            };
        
             //pagination
         
             $query="SELECT * FROM brand";
             $result= mysqli_query($link,$query); 
             $noOfRecords= mysqli_num_rows($result);
             $perPageRecords=3;
             $numOfPages= ceil($noOfRecords / $perPageRecords) ;
             $offSet= isset($_GET['offSet']) ? $_GET['offSet'] - 1 : 0;
             $ofSetRecord = $offSet * $perPageRecords;
 
 
             $query="SELECT * FROM brand limit $ofSetRecord, $perPageRecords";
             $result = mysqli_query($link,$query);
             $companies =  mysqli_fetch_all($result , 1);
          ?>
        <div class="container py-3">
            <div class="row">
              <div class="col-md-12">
                <div class="row justify-content-center">
                  <div class="col-md-6">
                   
                  </div>
                </div>
                <form method="POST"> 
                    <div class="form-group col-6">
                        <label >Brand</label>
                        <input type="text" class="form-control" name="brand_name"  placeholder="brand_name">
                    </div>
                    <button type="submit" class="btn btn-primary ml-3">Submit</button>
                </form>
                 <?php
                  if(isset($_POST['order_by'])){
                    $query      = "SELECT * FROM brand ORDER BY {$_POST['order_by']} {$_POST['order_with']}";
                    $result = mysqli_query($link,$query);
                    $companies =  mysqli_fetch_all($result , 1);
                   
                }else
                {
                    $query      = "SELECT * FROM brand";
                    $result= mysqli_query($link,$query);
                } 
                 ?>
                 <div class="pt-5 col-12">
                    <div class="col-12">
                        <div class="row">
                            <div class="col-6">
                            <form method="POST" class="form_inline">
                                <div class="form-group col-2 mt-2 d-inline-block">
                                    <select name="order_by">
                                        <option value="brand_name">Order by</option>
                                    </select>
                                </div>
                                <div class="form-group col-2 mt-2 d-inline-block">
                                    <select name="order_with">
                                        <option value="asc">Assending</option>
                                        <option value="desc">Decending</option>
                                    </select>
                                </div>
                               <div class="form-group col-2 mt-2 d-inline-block">
                                    <button type="submit" name= "sorting" class="btn btn-primary ml-4 p-1">Sort</button>
                                </div>
                            </form>
                            </div>
                            <?php
                                 if(isset($_POST['filter_with']) && !empty(trim($_POST['filter_with'])))
                                 {
                                     $query = "SELECT * FROM brand  WHERE brand.brand_name Like \"%{$_POST['filter_with']}%\"  ";
                                     $result= mysqli_query($link,$query);
                                     $companies =  mysqli_fetch_all($result , 1);
                                    
                                    
                                 }else{
                                     $query="SELECT * FROM brand";
                                     $result= mysqli_query($link,$query);
                                 }
                                
                             ?>
                            <div class="col-6 float-left">
                            <form method="POST" class="form-inline">
                                <div class="form-group  mt-2">
                                    <input type="text" class="form-control" name ="filter_with" placeholder = "Search....">
                                </div>
                                <div class="form-group mt-2">
                                    <input type="submit" class="btn btn-primary ml-3" value="filter">
                                </div>
            
                             </form>
                            </div>
                        </div>
                    </div>
                    <table class="table table-striped pt-2">
                        <thead>
                            <tr>
                            <th scope="col">#</th>
                            <th scope="col">Brand</th>
                            <th scope="col"> Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($companies as $brand){
                            ?>
                            <tr>
                                <td><?php echo $brand['id'];?></td>
                                <td><?php echo $brand['brand_name'];?></td>
                                <td>
                                    <a href= "brand_edit.php?brand_id=<?php echo $brand['id']; ?>" class="btn btn-primary"> <i class="fas fa-edit"></i></a>
                                    <a href= "brand_delete.php?brand_id=<?php echo $brand['id'];?>" class="btn btn-danger"> <i class="fas fa-trash-alt"></i></a>
                                </td>
                            </tr>
                            <?php    
                            }
                            ?>
                        </tbody>
                    </table>
                    <?php
                        for($i=1; $i<= $numOfPages; $i++)  
                        {
                            echo "<a href='brand.php?offSet=$i' class='btn btn-outline-primary'>$i</a>";
                        }     
                    ?>
                </div>
              </div><!--/col-->
            </div><!--/row-->
          </div><!--/container-->

       

        <?php include('footer.php'); ?>