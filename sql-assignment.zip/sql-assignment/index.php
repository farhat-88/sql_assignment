<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
<?php !isset($_SESSION['user_id']) ? header('location:login.php') : ''?>

     