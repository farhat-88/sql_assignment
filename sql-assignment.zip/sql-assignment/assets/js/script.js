$(document).ready(function(){
    $('.submit_form').on('click',function(event){
        event.preventDefault();
        const userData={};
      
        document.querySelectorAll('input').forEach(element =>{
          userData[element.name] = element.value;
      
        });
    
        $.ajax({
            data : userData,
            url : 'ajaxRegistration.php',
            type:'POST',
            dataType:'JSON',
            success:function(response){
                 swal({
                        icon: response.status,
                        text: response.message,
                        
                    }).then( () => {
                        if(response.status == 'success'){
                            window.location.href="http://localhost/sql-assignment/login.php"
                        }
                     
                    });
            } 
        })
       
    })
})