<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
        <?php
        
            if(isset($_POST['submit']))
            {
                if(isset($_FILES['file_upload']) &&!($_FILES['file_upload']['error']))
               {
                    $ext       = ['jpeg','jpg','png'];
                    $file_name = $_FILES['file_upload']['name'];
                    $tmp_name  = $_FILES['file_upload']['tmp_name'];
                    $filename_explode = explode('.',$file_name);
                    $file_extension = array_pop($filename_explode);
                    $file_size = $_FILES['file_upload']['size'];
                    $new_file_name = hash("sha256",$file_name.time()).".$file_extension";


                    if(in_array($file_extension,$ext))
                    {
                        if($file_size <= FILE_SIZE)
                        {

                             
                                if(move_uploaded_file($tmp_name,IMAGE_UPLOAD_PATH."$new_file_name"))
                                {
                                    $query  = "INSERT INTO product(product_name, price, file_name, cate_id) VALUES ('{$_POST['product_name']}',
                                    '{$_POST['price']}', '$new_file_name','{$_POST['cate_id']}') "; 

                                    $result =  mysqli_query ($link, $query);
                    
                                    if(mysqli_errno($link))
                                        {
                                            echo mysqli_error($link);
                                        }
                    
                                    if($result)
                                        { 
                                          
                                            header('location:products.php');
                                        }
                                }
                            
                            else{
                                echo "something is wrong";
                            }
                        }
                        else{
                            echo "file size is too long";
                        }

                    }
                    else
                    {
                        echo "file extension not supported";
                    }
               }
            }
            ?>
           
             <?php
                  
                  
        
            $query      = "SELECT * FROM category";
            $result     =  mysqli_query($link, $query);
            $categories   =  mysqli_fetch_all($result , 1);
            
            $query="SELECT product.id,product.product_name,product.price,product.file_name,category.category_name 
            FROM product INNER JOIN category ON product.cate_id = category.id";
            $result= mysqli_query($link,$query);
             
            $noOfRecords= mysqli_num_rows($result);
            $perPageRecords=3;
            $numOfPages= ceil($noOfRecords / $perPageRecords) ;
            $offSet= isset($_GET['offSet']) ? $_GET['offSet'] - 1 : 0;
            $ofSetRecord = $offSet * $perPageRecords;


            $query="SELECT product.id,product.product_name,product.price,product.file_name,category.category_name 
            FROM product INNER JOIN category ON product.cate_id = category.id limit $ofSetRecord, $perPageRecords";
            $result= mysqli_query($link,$query);
            $products= mysqli_fetch_all($result, 1);

          ?>

        <div class="container py-3">
            <div class="row">
              <div class="col-md-12">
                <div class="row justify-content-center">
                  <div class="col-md-12">
                    <form method="POST" enctype="multipart/form-data"> 
                        <div class="form-group col-6">
                            <label >Title</label>
                            <input type="text" class="form-control" name="product_name"  placeholder="Title">
                        </div>

                        <div class="form-group col-6">
                            <label >Price</label>
                            <input type="text" class="form-control" name="price"  placeholder="Price">
                        </div>

                        <div class="input-group mb-3 col-6">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Upload</span>
                            </div>
                            <div class="custom-file">
                                <input type="file" name="file_upload" class="custom-file-input" id="inputGroupFile01">
                                <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                            </div>
                        </div>

                        <div class="form-group col-6">
                            <label >category-id</label>
                            <select name = "cate_id" class="form-control">
                                <option value = "">Select Category</option>

                                <?php foreach($categories as $category){
                                ?>
                                <option value = "<?php echo $category["id"]?> ">
                                    <?php echo $category["category_name"]?>
                                </option>
                                <?php
                                }?>
                            </select>
                                
                        </div>
                        <button type="submit" name= "submit" class="btn btn-primary ml-3">Submit</button>
                    </form>
                   <?php
                       if(isset($_POST['order_by'])){
                        $query      = "SELECT product.id,product.product_name,product.price,product.file_name,category.category_name 
                        FROM product INNER JOIN category ON product.cate_id = category.id ORDER BY {$_POST['order_by']} {$_POST['order_with']}";
                        $result = mysqli_query($link,$query);
                        $products =  mysqli_fetch_all($result , 1);
                       
                    }else
                    {
                        $query      = "SELECT * FROM product";
                        $result= mysqli_query($link,$query);
                    } 
                   ?>
                    <div class="col-12 mt-3">
                        <div class="col-12">
                            <div class="row">
                                <div class="col-6">
                                    <form method="POST" class="form_inline">
                                        <div class="form-group mt-2 d-inline-block">
                                            <select name="order_by">
                                                <option value="category_name">Order by Title</option>
                                                <option value="category_name">Order by Amount</option>
                                                <option value="category_name">Order by category</option>
                                            </select>
                                        </div>
                                        <div class="form-group  mt-2 d-inline-block">
                                            <select name="order_with">
                                                <option value="asc">Assending</option>
                                                <option value="desc">Decending</option>
                                            </select>
                                        </div>
                                        <div class="form-group  mt-2 d-inline-block">
                                            <button type="submit" name= "sorting" class="btn btn-primary p-1">Sort</button>
                                        </div>
                                    </form>
                                </div>
                                <?php
                                 if(isset($_POST['filter_by']) && !empty(trim($_POST['filter_by'])))
                                 {
                                 $query = "SELECT product.id,product.product_name,product.price,product.file_name,category.category_name 
                                             FROM product INNER JOIN category ON product.cate_id = category.id 
                                             WHERE product.product_name Like \"%{$_POST['filter_by']}%\" or 
                                             product.price Like \"%{$_POST['filter_by']}%\" or 
                                             category.category_name Like \"%{$_POST['filter_by']}%\" 
                                             ";
                                             $result= mysqli_query($link,$query);
                                             $products= mysqli_fetch_all($result, 1); 
                                           
                                 
                                 
                                 }else
                                 
                                     {
                                         $query = "SELECT product.id,product.product_name,product.price,product.file_name,category.category_name 
                                         FROM product INNER JOIN category ON product.cate_id = category.id ";
                                         $result= mysqli_query($link,$query);
                                     }
                                ?>
                                <div class="col-6">
                                     <form method="POST" class="form-inline float-right">
                                        <div class="form-group  mt-2">
                                            <input type="text" class="form-control" name ="filter_by" placeholder = "Search....">
                                        </div>
                                        <div class="form-group mt-2">
                                            <input type="submit" class="btn btn-primary ml-3" value="filter">
                                        </div>
                                        
                                    </form>
                                </div>
                            </div>
                        </div>
                       
                        
                        <table class="table table-striped pt-2">
                            <thead>
                                <tr>
                                <th scope="col">#</th>
                                <th scope="col">Tittle</th>
                                <th scope="col">Amount</th>
                                <th scope="col">Image</th>
                                <th scope="col">Category_name</th>
                                <th scope="col"> Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                if(count($products) > 0){
                                ?>
                                <?php foreach($products as $product){
                                ?>
                                <tr>
                                    <td><?php echo $product['id'];?></td>
                                    <td><?php echo $product['product_name'];?></td>
                                    <td><?php echo $product['price'];?></td>
                                    <td><img width="100" height = "100" src="<?php echo IMAGE_UPLOAD_PATH."{$product['file_name']}";?>" alt="<?php echo $product['file_name'];?>" class="rounded img-thumbnail"></td>
                                    <td><?php echo $product['category_name'];?></td>
                                    <td>
                                        <a href= "edit_product.php?product_id=<?php echo $product['id']; ?>" class="btn btn-primary"><i class="fas fa-edit"></i></a>
                                        <a href= "product_delete.php?product_id=<?php echo $product['id']; ?>" class="btn btn-danger"><i class="fas fa-trash-alt"></i></a>
                                    </td>
                                </tr>
                                <?php    
                                }
                                ?>
                                <?php
                                } else{?>
                                <tr>
                                    <td>RECORD NOT FOUND</td>
                                </tr>
                            <?php
                                }
                                ?>
                            </tbody>
                        </table>
                        <?php
                                for($i=1; $i<= $numOfPages; $i++)  
                                {
                                    echo "<a href='products.php?offSet=$i' class='btn btn-outline-primary'>$i</a>";
                                }     
                        ?>
                    </div>
                  </div>
                </div>
             
                </div>
              </div><!--/col-->
            </div><!--/row-->
          </div><!--/container-->


        
        

      
        <?php include('footer.php'); ?>