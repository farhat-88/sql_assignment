<?php include('header.php'); ?>
        <?php
           
           if(isset($_POST['submit']))
           {
                if(!empty($_POST['category_name'] && $_POST['brand_id']))
                { 
                    $query  = "UPDATE category  SET 
                    category_name = '{$_POST['category_name']}', 
                    brand_id = '{$_POST['brand_id']}'
                    WHERE  id = '{$_POST['category_id']}' " ;
                    $result =  mysqli_query ($link, $query);

                    if(mysqli_errno($link))
                    {
                        echo mysqli_error($link);
                    }

                    if($result)
                    {
                        header('location:category.php');
                    }
                }
               
            };
        
        ?>
        <?php
            if(isset($_GET['category_id']))
            {
                $query      = "SELECT * FROM category where id = '{$_GET['category_id']}'";
                $result     =  mysqli_query($link, $query);
                $category   =  mysqli_fetch_assoc($result);  
            }
        ?>
        <?php
        
        
        $query      = "SELECT * FROM brand";
        $result     =  mysqli_query($link, $query);
        $companies =  mysqli_fetch_all($result , 1);
 
        ?>
        <!-- tenrarory conditions
        (conditions ? true : (condition ? true : false)) -->
               
        <form method="POST"> 
           
            <div class="form-group col-6">
                <label >category name</label>
                <input type="text" class="form-control" name="category_name"  placeholder="category_name"
                value = "<?php echo (isset($_POST['category_name']) ? $_POST['category_name'] : 
                                  (isset($category['category_name']) ? $category['category_name'] : 
                        '' )) ?> ">
            </div>

            

            <div class="form-group col-6">
                <label >brand</label>
                <select name = "brand_id" class="form-control">
                    <option value = "">Select brand name</option>
                    <?php foreach($companies as $brand){
                    ?>
                    <option value = "<?php echo $category['id']?>"
                    <?php echo (isset($_POST['brand_id']) &&  $_POST['brand_id'] == $brand['id'] ? 'selected' :
                            (isset($category['brand_id']) &&  $category['brand_id'] == $brand['id']  ? 'selected' : 
                          '' ))
                            ?>>
                           
                        <?php echo $brand['brand_name']?>
                    </option>
                    
                    <?php
                    }?>
                </select>
                    
            </div>
            <input type="hidden" class="form-control" name="category_id"  
                value="<?php echo (isset($_GET['category_id']) ? $_GET['category_id'] : '')?>">

            <button type="submit" name= "submit" class="btn btn-primary ml-3">UPDATE</button>
        </form>
        
        <?php include('footer.php'); ?>
      