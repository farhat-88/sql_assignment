<?php

    require_once('constant.php');

    $link = mysqli_connect(HOST, USERNAME, PASSWORD, DB_NAME);

    if (mysqli_connect_error())

    {
        
        echo mysqli_connect_error();

    };

?>