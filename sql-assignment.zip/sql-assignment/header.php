<?php session_start()?>
<!Doctype html>
<html>
    <head>
        <title> STORE </title>
        <!-- Bootstrap -->
        <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <!--fontawsome-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
    </head>
    <body>
    

        <?php require_once('connection.php');?>
        