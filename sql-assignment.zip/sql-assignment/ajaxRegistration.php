<?php require_once('connection.php');?>
<?php


 if(isset($_POST['user_name']))
 {
   
     $query_email="SELECT * FROM users where email = '{$_POST['email']}'";
     $resultSet= mysqli_query($link,$query_email);
    
     if(mysqli_num_rows($resultSet) <= 0)
     {
         if($_POST['confirm_password'] == $_POST['password'])
         {
             $password =password_hash($_POST['password'],PASSWORD_DEFAULT);

             $query  = "INSERT INTO users (name, email, password) VALUES('{$_POST['user_name']}',
             '{$_POST['email']}','$password')";
  
                 $result =  mysqli_query ($link, $query);
                
             if($result)
             {
               
                 echo json_encode (['status'=>'success','message'=>'Account registered']);
              }
         }else{
             echo json_encode (['status'=>'error','message'=>'Confirm password and password are not same']);
         }
     }else{
         echo json_encode (['status'=>'error','message'=>'email already taken']);
    
     }

    
 }
?>