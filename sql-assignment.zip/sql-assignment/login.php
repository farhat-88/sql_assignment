<?php include('header.php'); ?>
<?php isset($_SESSION['user_id']) ? header('location:index.php') : ''?>
        <?php
            if(isset($_POST['email']) && isset($_POST['password']))
            {
                $query= "SELECT * FROM users where email = '{$_POST['email']}'";
                $result = mysqli_query($link,$query);

                if(mysqli_num_rows($result) > 0)
                {
                    $user =mysqli_fetch_assoc($result);

                    if(password_verify($_POST['password'], $user['password']))
                    {
                        $_SESSION['user_id'] = $user['id'];
                      header('location:index.php');
                    }
                    else{
                        $errors['password']=  "crediantals are not correct";
                    }
                }
                else
                {
                    $errors['email'] = "email not exits";
                }
            }
    
    ?>
    <div class="container py-3">
            <div class="row">
              <div class="col-md-12">
                <div class="row justify-content-center">
                  <div class="col-md-6">
                    <form method="POST" class="m-5" >
            
                        <div class="form-group col-12">
                            <label for="exampleInputEmail1">Email address</label>
                            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="email">
                            <?php echo isset($errors['email']) ? "<div class='alert alert-danger' role='alert'>{$errors['email']}
                                </div>": ''?> 
                        </div>
                        <div class="form-group col-12">
                            <label for="exampleInputPassword1">Password</label>
                            <input type="password" class="form-control" placeholder="Password" name="password">
                            <?php echo isset($errors['password']) ? "<div class='alert alert-danger' role='alert'>{$errors['password']}
                                </div>": ''?> 
                        </div>
                        
                        <button type="submit" class="btn btn-primary ml-3 ">Submit</button>
                        <p>Don't have an account? <a href="regisration.php">Sign up now</a>.</p>
                    </form>
                  </div>
                </div>

              </div><!--/col-->
            </div><!--/row-->
          </div><!--/container-->
       
     
    <?php include('footer.php'); ?>

