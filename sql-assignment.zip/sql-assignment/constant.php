<?php

    define('HOST','localhost');

    define('USERNAME','root');

    define('PASSWORD','');
    
    define('DB_NAME','store');

    define('FILE_SIZE',10485760);

    define('ASSETS_UPLOAD','assets/');

    define('IMAGE_UPLOAD_PATH',ASSETS_UPLOAD.'images/');

?>