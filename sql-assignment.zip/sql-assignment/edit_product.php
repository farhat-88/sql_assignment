
<?php include('header.php'); ?>
        <?php
           if(isset($_POST['submit']))
           {
                if(!empty($_POST['product_name'] && $_POST['price'] && $_POST['cate_id']))
                { 
                   
                    if(isset($_FILES['file_upload']) &&!($_FILES['file_upload']['error']))
                    {
                         $ext       = ['jpeg','jpg','png'];
                         $file_name = $_FILES['file_upload']['name'];
                         $tmp_name  = $_FILES['file_upload']['tmp_name'];
                         $filename_explode = explode('.',$file_name);
                         $file_extension = array_pop($filename_explode);
                         $file_size = $_FILES['file_upload']['size'];
                         $new_file_name = hash("sha256",$file_name.time()).".$file_extension";
     
     
                         if(in_array($file_extension,$ext))
                         {
                             if($file_size <= FILE_SIZE)
                             {
     
                                  
                                     if(move_uploaded_file($tmp_name,IMAGE_UPLOAD_PATH."$new_file_name"))
                                     {
                                        $query  = "UPDATE product SET product_name = '{$_POST['product_name']}', 
                                        price = '{$_POST['price']}', file_name='$new_file_name', cate_id = '{$_POST['cate_id']}'
                                        WHERE  id = '{$_POST['product_id']}' " ;

                                        $result =  mysqli_query ($link, $query);
                        
                                        if(mysqli_errno($link))
                                            {
                                                echo mysqli_error($link);
                                            }
                        
                                        if($result)
                                            { 
                                              
                                                header('location:products.php');
                                            }
                                       
                                      }
                                 
                                 else{
                                     echo "something is wrong";
                                 }
                             }
                             else{
                                 echo "file size is too long";
                             }
     
                         }
                         else
                         {
                             echo "file extension not supported";
                         }
                    }
                }
               
            };
        
        ?>
        <?php
            if(isset($_GET['product_id']))
            {
                $query      = "SELECT * FROM product where id = '{$_GET['product_id']}'";
                $result     =  mysqli_query($link, $query);
                $product   =  mysqli_fetch_assoc($result);  
            }
        ?>
        <?php
        
        
        $query      = "SELECT * FROM category";
        $result     =  mysqli_query($link, $query);
        $categories =  mysqli_fetch_all($result , 1);
 
        ?>
          
        <!-- tenrarory conditions
        (conditions ? true : (condition ? true : false)) -->
               
        <form method="POST" enctype="multipart/form-data"> 
           
            <div class="form-group col-6">
                <label >Product</label>
                <input type="text" class="form-control" name="product_name"  placeholder="product_name"
                value = "<?php echo (isset($_POST['product_name']) ? $_POST['product_name'] : 
                                  (isset($product['product_name']) ? $product['product_name'] : 
                        '' )) ?> ">
            </div>

            <div class="form-group col-6">
                <label >Price</label>
                <input type="text" class="form-control" name="price"  placeholder="Price"
                value = "<?php echo (isset($_POST['price']) ? $_POST['price'] : 
                                  (isset($product['price']) ? $product['price'] : 
                        '' )) ?> ">
            </div>

            <div class="form-group col-6">
                <label >Image</label>
                <img width="100" height = "100" src="<?php echo IMAGE_UPLOAD_PATH."{$product['file_name']}";?>" alt="<?php echo $product['file_name'];?>" class="rounded img-thumbnail">
                <div class="input-group mb-3 col-6">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Upload</span>
                    </div>
                    <div class="custom-file">
                        <input type="file" name="file_upload" class="custom-file-input" id="inputGroupFile01">
                        <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                    </div>
                </div>
            </div>

            <div class="form-group col-6">
                <label >category</label>
                <select name = "cate_id" class="form-control">
                    <option value = "">Select Category</option>
                    <?php foreach($categories as $category){
                    ?>
                    <option value = "<?php echo $category['id']?>"<?php echo (isset($_POST['cate_id']) &&  $_POST['cate_id'] == $category['id'] ? 'selected' :
                            (isset($product['cate_id']) &&  $product['cate_id'] == $category['id']  ? 'selected' : 
                          '' ))
                            ?>>
                           
                        <?php echo $category['category_name']?>
                    </option>
                    
                    <?php
                    }?>
                </select>
                    
            </div>
            <input type="hidden" class="form-control" name="product_id"  
                value="<?php echo (isset($_GET['product_id']) ? $_GET['product_id'] : '')?>">

            <button type="submit" name= "submit" class="btn btn-primary ml-3">UPDATE</button>
        </form>
        
        <?php include('footer.php'); ?>
      