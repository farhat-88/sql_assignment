
    
       <!-- jQuery http://jquery.com -->
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
       <!-- Bootstrap http://getbootstrap.com -->
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <!--alert libarary-->
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <!--custom script-->
        <script src="assets/js/script.js"></script>
        

</body>
</html>