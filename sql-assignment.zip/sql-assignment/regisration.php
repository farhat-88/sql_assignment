
       <?php include('header.php'); ?>
       <?php isset($_SESSION['user_id']) ? header('location:index.php') : ''?>

        <form method="POST" id ="registration_form">
            <h1 class="ml-3"> Sign Up</h1>
            <p class="ml-3">Please fill this form to create an account.</p>
        <div class="form-group col-6">
            <label for="exampleInputEmail1">Name</label>
            <input type="text" class="form-control" placeholder="user name" name="user_name">
          
        </div>
        <div class="form-group col-6">
            <label for="exampleInputEmail1">Email address</label>
            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="email">
            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
        </div>
        <div class="form-group col-6">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" class="form-control" placeholder="Password" name="password">
        </div>
        <div class="form-group col-6">
            <label for="exampleInputPassword1">Confirm Password</label>
            <input type="password" class="form-control" id="exampleInputPassword1" placeholder=" confirm Password" name="confirm_password">
        </div>
       
        <button type="submit" class="btn btn-primary submit_form ml-3">Submit</button>
    </form>
      
 <?php include('footer.php'); ?>


       