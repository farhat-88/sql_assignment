<?php include('header.php'); ?>
        <?php
           
           if(isset($_POST['brand_name']) && isset($_POST['brand_id']))
           {
                if(!empty($_POST['brand_name']))
                { 
                    $query  = "UPDATE brand  SET brand_name = '{$_POST['brand_name']}'  WHERE  id = '{$_POST['brand_id']}' " ;
                    $result =  mysqli_query ($link, $query);
                    $brand= mysqli_fetch_assoc($result);

                    if(mysqli_errno($link))
                    {
                        echo mysqli_error($link);
                    }

                    if($result)
                    {
                        header('location:brand.php');
                    }
                }
               
            };
        
        ?>

        <?php
            if(isset($_GET['brand_id']))
            {
                $query      = "SELECT * FROM brand where id = '{$_GET['brand_id']}'";
                $result =  mysqli_query ($link, $query);
                $brand= mysqli_fetch_assoc($result);
              
            }
        ?>

        <form method="POST">  
            <div class="form-group col-6">

                <label >Brand Name</label>
                <input type="text" class="form-control" name="brand_name"  placeholder="brand_name"
                value = "<?php echo (isset($_POST['brand_name']) ? $_POST['brand_name'] : 
                                  (isset($brand['brand_name']) ? $brand['brand_name'] : 
                        '' )) ?> ">
                
                <input type="hidden" class="form-control" name="brand_id"  
                value="<?php echo (isset($brand['id']) ? $brand['id'] : '')?>">

            </div>
            <button type="submit" class="btn btn-primary ml-3">UPDATE</button>
        </form>
        

        <?php include('footer.php'); ?>